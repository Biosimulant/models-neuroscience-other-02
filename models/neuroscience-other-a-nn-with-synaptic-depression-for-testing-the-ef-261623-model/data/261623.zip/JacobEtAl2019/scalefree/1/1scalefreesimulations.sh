#!/bin/bash

./macgregor_20_scalefree < parameters.txt > output_20_1.txt
mv spikes.txt spikes_20_1.txt

./macgregor_25_scalefree < parameters.txt > output_25_1.txt
mv spikes.txt spikes_25_1.txt

./macgregor_30_scalefree < parameters.txt > output_30_1.txt
mv spikes.txt spikes_30_1.txt

./macgregor_35_scalefree < parameters.txt > output_35_1.txt
mv spikes.txt spikes_35_1.txt

./macgregor_40_scalefree < parameters.txt > output_40_1.txt
mv spikes.txt spikes_40_1.txt



