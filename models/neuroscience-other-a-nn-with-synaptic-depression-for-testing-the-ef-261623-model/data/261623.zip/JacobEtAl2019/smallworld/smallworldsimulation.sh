#!/bin/bash

#./macgregor10 < parameters.txt > output_10_1.txt
#mv spikes.txt spikes_10_1.txt

#./macgregor20 < parameters.txt > output_20_1.txt
#mv spikes.txt spikes_20_1.txt

#./macgregor30 < parameters.txt > output_30_1.txt
#mv spikes.txt spikes_30_1.txt

#./macgregor40 < parameters.txt > output_40_1.txt
#mv spikes.txt spikes_40_1.txt

#./macgregor50 < parameters.txt > output_50_1.txt
#mv spikes.txt spikes_50_1.txt


#./macgregor10 < parameters.txt > output_10_2.txt
#mv spikes.txt spikes_10_2.txt

#./macgregor20 < parameters.txt > output_20_2.txt
#mv spikes.txt spikes_20_2.txt

#./macgregor30 < parameters.txt > output_30_2.txt
#mv spikes.txt spikes_30_2.txt

#./macgregor40 < parameters.txt > output_40_2.txt
#mv spikes.txt spikes_40_2.txt

#./macgregor50 < parameters.txt > output_50_2.txt
#mv spikes.txt spikes_50_2.txt


#./macgregor10 < parameters.txt > output_10_3.txt
#mv spikes.txt spikes_10_3.txt

#./macgregor20 < parameters.txt > output_20_3.txt
#mv spikes.txt spikes_20_3.txt

#./macgregor30 < parameters.txt > output_30_3.txt
#mv spikes.txt spikes_30_3.txt

#./macgregor40 < parameters.txt > output_40_3.txt
#mv spikes.txt spikes_40_3.txt

#./macgregor50 < parameters.txt > output_50_3.txt
#mv spikes.txt spikes_50_3.txt


#./macgregor10 < parameters.txt > output_10_4.txt
#mv spikes.txt spikes_10_4.txt

#./macgregor20 < parameters.txt > output_20_4.txt
#mv spikes.txt spikes_20_4.txt

#./macgregor30 < parameters.txt > output_30_4.txt
#mv spikes.txt spikes_30_4.txt

#./macgregor40 < parameters.txt > output_40_4.txt
#mv spikes.txt spikes_40_4.txt

#./macgregor50 < parameters.txt > output_50_4.txt
#mv spikes.txt spikes_50_4.txt


#./macgregor10 < parameters.txt > output_10_5.txt
#mv spikes.txt spikes_10_5.txt

./macgregor20 < parameters.txt > output_20_5.txt
mv spikes.txt spikes_20_5.txt

./macgregor30 < parameters.txt > output_30_5.txt
mv spikes.txt spikes_30_5.txt

./macgregor40 < parameters.txt > output_40_5.txt
mv spikes.txt spikes_40_5.txt

./macgregor50 < parameters.txt > output_50_5.txt
mv spikes.txt spikes_50_5.txt