Simulations for uniform connectivity:

In order to keep the total number of connections comparable to that of scale free, I have introduced a new parameter value_uniform in layer.cpp that takes on a random number.

Also, the d parameter is no longer relevant

10 - value_uniform limit = 0.625
15 - value_uniform limit = 0.525
20 - value_uniform limit = 0.355
25 - value_uniform limit = 0.315
30 - value_uniform limit = 0.245
50 - value_uniform limit = 0.14
