#!/bin/bash

#./macgregor_uniform_10 < parameters.txt > output_10_1.txt
#mv spikes.txt spikes_10_1.txt

#./macgregor_uniform_15 < parameters.txt > output_15_1.txt
#mv spikes.txt spikes_15_1.txt

#./macgregor_uniform_20 < parameters.txt > output_20_1.txt
#mv spikes.txt spikes_20_1.txt

#./macgregor_uniform_25 < parameters.txt > output_25_1.txt
#mv spikes.txt spikes_25_1.txt

#./macgregor_uniform_30 < parameters.txt > output_30_1.txt
#mv spikes.txt spikes_30_1.txt



#./macgregor_uniform_10 < parameters.txt > output_10_2.txt
#mv spikes.txt spikes_10_2.txt

#./macgregor_uniform_15 < parameters.txt > output_15_2.txt
#mv spikes.txt spikes_15_2.txt

#./macgregor_uniform_20 < parameters.txt > output_20_2.txt
#mv spikes.txt spikes_20_2.txt

#./macgregor_uniform_25 < parameters.txt > output_25_2.txt
#mv spikes.txt spikes_25_2.txt

#./macgregor_uniform_30 < parameters.txt > output_30_2.txt
#mv spikes.txt spikes_30_2.txt



#./macgregor_uniform_10 < parameters.txt > output_10_3.txt
#mv spikes.txt spikes_10_3.txt

#./macgregor_uniform_15 < parameters.txt > output_15_3.txt
#mv spikes.txt spikes_15_3.txt

#./macgregor_uniform_20 < parameters.txt > output_20_3.txt
#mv spikes.txt spikes_20_3.txt

#./macgregor_uniform_25 < parameters.txt > output_25_3.txt
#mv spikes.txt spikes_25_3.txt

#./macgregor_uniform_30 < parameters.txt > output_30_3.txt
#mv spikes.txt spikes_30_3.txt



#./macgregor_uniform_10 < parameters.txt > output_10_4.txt
#mv spikes.txt spikes_10_4.txt

#./macgregor_uniform_15 < parameters.txt > output_15_4.txt
#mv spikes.txt spikes_15_4.txt

#./macgregor_uniform_20 < parameters.txt > output_20_4.txt
#mv spikes.txt spikes_20_4.txt

#./macgregor_uniform_25 < parameters.txt > output_25_4.txt
#mv spikes.txt spikes_25_4.txt

#./macgregor_uniform_30 < parameters.txt > output_30_4.txt
#mv spikes.txt spikes_30_4.txt



./macgregor_uniform_10 < parameters.txt > output_10_5.txt
mv spikes.txt spikes_10_5.txt

./macgregor_uniform_15 < parameters.txt > output_15_5.txt
mv spikes.txt spikes_15_5.txt

./macgregor_uniform_20 < parameters.txt > output_20_5.txt
mv spikes.txt spikes_20_5.txt

./macgregor_uniform_25 < parameters.txt > output_25_5.txt
mv spikes.txt spikes_25_5.txt

./macgregor_uniform_30 < parameters.txt > output_30_5.txt
mv spikes.txt spikes_30_5.txt