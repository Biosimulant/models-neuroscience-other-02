Note: this was done just training the weights during the simulation and not using presaved weights. So if rereun values will be slightly different.
