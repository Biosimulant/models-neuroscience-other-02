This entry has source code for the model from:

Medlock et al. (2024) Encoding of vibrotactile stimuli by mechanoreceptors in rodent glabrous skin. *J Neuroscience*

The MATLAB file `Simulate_LTMR.m` simulates fitted generalized linear model (GLMs). Modify the variable `Neuron` in this file to any of the following values `Neuron1`, `Neuron2` `Neuron3` or `Neuron4`. You can also modify the variable `runs` to simulate different numbers of trials.