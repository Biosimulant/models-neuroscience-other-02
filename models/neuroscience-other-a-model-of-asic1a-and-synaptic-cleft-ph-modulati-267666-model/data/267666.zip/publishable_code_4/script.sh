for i in `seq 0 200`;
    do python runMultiProcs.py $i ;
    done;
