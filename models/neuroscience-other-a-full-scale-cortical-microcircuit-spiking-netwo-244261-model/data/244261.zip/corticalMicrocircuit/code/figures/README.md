### Figures repository

All figures generated are saved in this folder.
