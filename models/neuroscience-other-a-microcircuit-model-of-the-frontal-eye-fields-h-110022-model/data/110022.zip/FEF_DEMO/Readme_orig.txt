To run in matlab unzip the Folder FEF_DEMO.zip
and set the matlab path to it.

Change settings to the simulation in SetupDemo.m and
run the simulation with FEF_DEMO.m