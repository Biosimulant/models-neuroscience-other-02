% initialize_network creates a new struct for the populations, the
% connections and the inputs to the network. Sets the counters to zero.
%
% created: Jakob Heinzle 01/07

clear pops cons inputs

pops.npops=0;
cons.ncons=0;
inputs.ninputs=0;