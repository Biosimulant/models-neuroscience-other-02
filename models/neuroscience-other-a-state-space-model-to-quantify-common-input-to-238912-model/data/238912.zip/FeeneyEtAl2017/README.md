# Neural-models
This is a MATLAB based repository of neural modeling. Some of the work is used for future (or potential) publications. It is published as is with no warranty. 
