# hippocampus

The code in this repo runs the striatum-hippocampus model of Jesse Geerts, Fabian Chersi, Kimberly Stachenfeld and Neil 
Burgess. 