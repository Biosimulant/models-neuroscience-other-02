#include "NsGlobals.hh"

/**
 * Definition of global variables declared in Globals.hh
 */
Props props;
uint  simTime;
uint  timeStep;
