This is the model associated with the paper:

Kubota Y, Kondo S, Nomura M, Hatada S, Yamaguchi N, Mohamed AA, Karube
F, Lübke J, Kawaguchi (2015) Functional effects of distinct
innervation styles of pyramidal cells by fast spiking cortical
interneurons. Elife

The source code was contributed by the first author, Y Kubota.

Linux/Unix Usage:
After compiling the mod files start run.hoc with a command like
nrngui run.hoc

For more usage instructions on other platforms please see:
https://senselab.med.yale.edu/ModelDB/NEURON_DwnldGuide.html
