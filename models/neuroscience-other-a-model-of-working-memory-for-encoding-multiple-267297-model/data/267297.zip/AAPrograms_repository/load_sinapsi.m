if ~train_flag
    if SET_PATT==1
            load('sinapsi_SET1.mat')
    elseif SET_PATT==2
            load('sinapsi_SET2.mat')
    elseif SET_PATT==3
            load('sinapsi_SET3.mat')
    end
end