#ifndef _RANDOM_H
#define _RANDOM_H

float ran1(long *);
double gasdevbis(long *, double * , double* );

#endif
