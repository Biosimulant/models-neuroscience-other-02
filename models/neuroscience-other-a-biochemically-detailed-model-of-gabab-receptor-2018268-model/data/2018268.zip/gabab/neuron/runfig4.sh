nrnivmodl mechanisms

python3 drawmorph_extNTsyns.py #Save morphology data needed for panel A

mytol=1e-05
stimprob=0.5
SCdev=0.5
SC=0.2

for myseed in `seq 1 40`
do

GFLUX=0.0
GFLUXPRE=0.0
GABABdur=600.0
GABABdel=-400
for Nsyn in 200 300 400 500 600 700 800 900
do
  if [ -f spiking_extNTsyns_rh_lowmem_SC${SC}dev${SCdev}_Ntrials10_stim10000_600_${Nsyn}_gsyn0.001_Nterminalsrandom0of20_stimf20.0x${stimprob}_GABABdur600.0_GABABdel${GABABdel}_fluxGABAB${GFLUX}_${GFLUXPRE}_gSKv3_1bar_SKv3_1x2.5p0_apic650-1300_tol${mytol}_seed${myseed}.mat ]
  then
    echo "spiking_extNTsyns_rh_lowmem_SC${SC}dev${SCdev}_Ntrials10_stim10000_600_${Nsyn}_gsyn0.001_Nterminalsrandom0of20_stimf20.0x${stimprob}_GABABdur600.0_GABABdel${GABABdel}_fluxGABAB${GFLUX}_${GFLUXPRE}_gSKv3_1bar_SKv3_1x2.5p0_apic650-1300_tol${mytol}_seed${myseed}.mat exists"
  else
    echo "spiking_extNTsyns_rh_lowmem_SC${SC}dev${SCdev}_Ntrials10_stim10000_600_${Nsyn}_gsyn0.001_Nterminalsrandom0of20_stimf20.0x${stimprob}_GABABdur600.0_GABABdel${GABABdel}_fluxGABAB${GFLUX}_${GFLUXPRE}_gSKv3_1bar_SKv3_1x2.5p0_apic650-1300_tol${mytol}_seed${myseed}.mat does not exist, simulating"
    echo python3 calcSpiking_extNTsyns_rh_lowmem_manytrials_partialrandompresynGABA_GABABdel_givenpreflux_randomsc.py 10 ${SC} $SCdev 10000 600 $Nsyn 0.001 20 0 20 $stimprob $GABABdur $GABABdel $GFLUX $GFLUXPRE gSKv3_1bar_SKv3_1x2.5 p0 apic650-1300 $myseed $mytol
    python3 calcSpiking_extNTsyns_rh_lowmem_manytrials_partialrandompresynGABA_GABABdel_givenpreflux_randomsc.py 10 ${SC} $SCdev 10000 600 $Nsyn 0.001 20 0 20 $stimprob $GABABdur $GABABdel $GFLUX $GFLUXPRE gSKv3_1bar_SKv3_1x2.5 p0 apic650-1300 $myseed $mytol
  fi
done

GFLUXPRE=0.0
GABABdel=-400
Nsyn=500

for GFLUX in 2e-06 2.8e-06 3.1e-06 3.25e-06 3.4e-06 3.5e-06
do
    
    if [ -f spiking_extNTsyns_rh_lowmem_SC${SC}dev${SCdev}_Ntrials10_stim10000_600_${Nsyn}_gsyn0.001_Nterminalsrandom0of20_stimf20.0x${stimprob}_GABABdur600.0_GABABdel${GABABdel}_fluxGABAB${GFLUX}_${GFLUXPRE}_gSKv3_1bar_SKv3_1x2.5p0_apic650-1300_tol${mytol}_seed${myseed}.mat ]
    then
      echo "spiking_extNTsyns_rh_lowmem_SC${SC}dev${SCdev}_Ntrials10_stim10000_600_${Nsyn}_gsyn0.001_Nterminalsrandom0of20_stimf20.0x${stimprob}_GABABdur600.0_GABABdel${GABABdel}_fluxGABAB${GFLUX}_${GFLUXPRE}_gSKv3_1bar_SKv3_1x2.5p0_apic650-1300_tol${mytol}_seed${myseed}.mat exists"
    else
      echo "spiking_extNTsyns_rh_lowmem_SC${SC}dev${SCdev}_Ntrials10_stim10000_600_${Nsyn}_gsyn0.001_Nterminalsrandom0of20_stimf20.0x${stimprob}_GABABdur600.0_GABABdel${GABABdel}_fluxGABAB${GFLUX}_${GFLUXPRE}_gSKv3_1bar_SKv3_1x2.5p0_apic650-1300_tol${mytol}_seed${myseed}.mat does not exist, simulating"
      echo python3 calcSpiking_extNTsyns_rh_lowmem_manytrials_partialrandompresynGABA_GABABdel_givenpreflux_randomsc.py 10 ${SC} $SCdev 10000 600 $Nsyn 0.001 20 0 20 $stimprob $GABABdur $GABABdel $GFLUX $GFLUXPRE gSKv3_1bar_SKv3_1x2.5 p0 apic650-1300 $myseed $mytol
      python3 calcSpiking_extNTsyns_rh_lowmem_manytrials_partialrandompresynGABA_GABABdel_givenpreflux_randomsc.py 10 ${SC} $SCdev 10000 600 $Nsyn 0.001 20 0 20 $stimprob $GABABdur $GABABdel $GFLUX $GFLUXPRE gSKv3_1bar_SKv3_1x2.5 p0 apic650-1300 $myseed $mytol
    fi
done

GFLUX=3.25e-06
GFLUXPRE=3.25e-06
GABABdel=-400

for NspinesGABAB in 0 5 10 15 20
do
    
    if [ -f spiking_extNTsyns_rh_lowmem_SC${SC}dev${SCdev}_Ntrials10_stim10000_600_${Nsyn}_gsyn0.001_Nterminalsrandom${NspinesGABAB}of20_stimf20.0x${stimprob}_GABABdur600.0_GABABdel${GABABdel}_fluxGABAB${GFLUX}_${GFLUXPRE}_gSKv3_1bar_SKv3_1x2.5p0_apic650-1300_tol${mytol}_seed${myseed}.mat ]
    then
      echo "spiking_extNTsyns_rh_lowmem_SC${SC}dev${SCdev}_Ntrials10_stim10000_600_${Nsyn}_gsyn0.001_Nterminalsrandom${NspinesGABAB}of20_stimf20.0x${stimprob}_GABABdur600.0_GABABdel${GABABdel}_fluxGABAB${GFLUX}_${GFLUXPRE}_gSKv3_1bar_SKv3_1x2.5p0_apic650-1300_tol${mytol}_seed${myseed}.mat exists"
    else
      echo "spiking_extNTsyns_rh_lowmem_SC${SC}dev${SCdev}_Ntrials10_stim10000_600_${Nsyn}_gsyn0.001_Nterminalsrandom${NspinesGABAB}of20_stimf20.0x${stimprob}_GABABdur600.0_GABABdel${GABABdel}_fluxGABAB${GFLUX}_${GFLUXPRE}_gSKv3_1bar_SKv3_1x2.5p0_apic650-1300_tol${mytol}_seed${myseed}.mat does not exist, simulating"
      echo python3 calcSpiking_extNTsyns_rh_lowmem_manytrials_partialrandompresynGABA_GABABdel_givenpreflux_randomsc.py 10 ${SC} $SCdev 10000 600 $Nsyn 0.001 20 $NspinesGABAB 20 $stimprob $GABABdur $GABABdel $GFLUX $GFLUXPRE gSKv3_1bar_SKv3_1x2.5 p0 apic650-1300 $myseed $mytol
      python3 calcSpiking_extNTsyns_rh_lowmem_manytrials_partialrandompresynGABA_GABABdel_givenpreflux_randomsc.py 10 ${SC} $SCdev 10000 600 $Nsyn 0.001 20 $NspinesGABAB 20 $stimprob $GABABdur $GABABdel $GFLUX $GFLUXPRE gSKv3_1bar_SKv3_1x2.5 p0 apic650-1300 $myseed $mytol
    fi
done


GFLUXPRE=0.0
for GABABdel in -1000 -800 -600 -400 -200 0
do
    
  for NspinesGABAB in 0
  do
    
    if [ -f spiking_extNTsyns_rh_lowmem_SC${SC}dev${SCdev}_Ntrials10_stim10000_600_${Nsyn}_gsyn0.001_Nterminalsrandom${NspinesGABAB}of20_stimf20.0x${stimprob}_GABABdur600.0_GABABdel${GABABdel}_fluxGABAB${GFLUX}_${GFLUXPRE}_gSKv3_1bar_SKv3_1x2.5p0_apic650-1300_tol${mytol}_seed${myseed}.mat ]
    then
      echo "spiking_extNTsyns_rh_lowmem_SC${SC}dev${SCdev}_Ntrials10_stim10000_600_${Nsyn}_gsyn0.001_Nterminalsrandom${NspinesGABAB}of20_stimf20.0x${stimprob}_GABABdur600.0_GABABdel${GABABdel}_fluxGABAB${GFLUX}_${GFLUXPRE}_gSKv3_1bar_SKv3_1x2.5p0_apic650-1300_tol${mytol}_seed${myseed}.mat exists"
    else
      echo "spiking_extNTsyns_rh_lowmem_SC${SC}dev${SCdev}_Ntrials10_stim10000_600_${Nsyn}_gsyn0.001_Nterminalsrandom${NspinesGABAB}of20_stimf20.0x${stimprob}_GABABdur600.0_GABABdel${GABABdel}_fluxGABAB${GFLUX}_${GFLUXPRE}_gSKv3_1bar_SKv3_1x2.5p0_apic650-1300_tol${mytol}_seed${myseed}.mat does not exist, simulating"
      echo python3 calcSpiking_extNTsyns_rh_lowmem_manytrials_partialrandompresynGABA_GABABdel_givenpreflux_randomsc.py 10 ${SC} $SCdev 10000 600 $Nsyn 0.001 20 $NspinesGABAB 20 $stimprob $GABABdur $GABABdel $GFLUX $GFLUXPRE gSKv3_1bar_SKv3_1x2.5 p0 apic650-1300 $myseed $mytol
      python3 calcSpiking_extNTsyns_rh_lowmem_manytrials_partialrandompresynGABA_GABABdel_givenpreflux_randomsc.py 10 ${SC} $SCdev 10000 600 $Nsyn 0.001 20 $NspinesGABAB 20 $stimprob $GABABdur $GABABdel $GFLUX $GFLUXPRE gSKv3_1bar_SKv3_1x2.5 p0 apic650-1300 $myseed $mytol
    fi
  done

done

GFLUXPRE=3.25e-06
for GABABdel in -1000 -800 -600 -400 -200 0
do

for NspinesGABAB in 20
do
    
    if [ -f spiking_extNTsyns_rh_lowmem_SC${SC}dev${SCdev}_Ntrials10_stim10000_600_${Nsyn}_gsyn0.001_Nterminalsrandom${NspinesGABAB}of20_stimf20.0x${stimprob}_GABABdur600.0_GABABdel${GABABdel}_fluxGABAB${GFLUX}_${GFLUXPRE}_gSKv3_1bar_SKv3_1x2.5p0_apic650-1300_tol${mytol}_seed${myseed}.mat ]
    then
      echo "spiking_extNTsyns_rh_lowmem_SC${SC}dev${SCdev}_Ntrials10_stim10000_600_${Nsyn}_gsyn0.001_Nterminalsrandom${NspinesGABAB}of20_stimf20.0x${stimprob}_GABABdur600.0_GABABdel${GABABdel}_fluxGABAB${GFLUX}_${GFLUXPRE}_gSKv3_1bar_SKv3_1x2.5p0_apic650-1300_tol${mytol}_seed${myseed}.mat exists"
    else
      echo "spiking_extNTsyns_rh_lowmem_SC${SC}dev${SCdev}_Ntrials10_stim10000_600_${Nsyn}_gsyn0.001_Nterminalsrandom${NspinesGABAB}of20_stimf20.0x${stimprob}_GABABdur600.0_GABABdel${GABABdel}_fluxGABAB${GFLUX}_${GFLUXPRE}_gSKv3_1bar_SKv3_1x2.5p0_apic650-1300_tol${mytol}_seed${myseed}.mat does not exist, simulating"
      echo python3 calcSpiking_extNTsyns_rh_lowmem_manytrials_partialrandompresynGABA_GABABdel_givenpreflux_randomsc.py 10 ${SC} $SCdev 10000 600 $Nsyn 0.001 20 $NspinesGABAB 20 $stimprob $GABABdur $GABABdel $GFLUX $GFLUXPRE gSKv3_1bar_SKv3_1x2.5 p0 apic650-1300 $myseed $mytol
      python3 calcSpiking_extNTsyns_rh_lowmem_manytrials_partialrandompresynGABA_GABABdel_givenpreflux_randomsc.py 10 ${SC} $SCdev 10000 600 $Nsyn 0.001 20 $NspinesGABAB 20 $stimprob $GABABdur $GABABdel $GFLUX $GFLUXPRE gSKv3_1bar_SKv3_1x2.5 p0 apic650-1300 $myseed $mytol
    fi
done

done

done #for myseed in `seq 1 40`
