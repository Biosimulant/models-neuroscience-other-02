nrnivmodl mechanisms

PasActLen='100 20'
decay=1.0
EL=-90.0
gNa=3.9
gK=0.077
minCa=50e-6

for par in p0; do
  for T in 150.0 200.0 300.0 500.0 700.0 900.0 1300.0 1600.0; do echo "python3 presynGABAB_actpasaxon_rxdrel6_varstim_no1stglu_recVGCC.py $gNa $gK 3e-05 ${EL} $decay $minCa $par None       2 $T $PasActLen 1 0.3 5e-06 1.0 100.0 1.0 1.0 1.0 0.001 0.001 1 0";python3 presynGABAB_actpasaxon_rxdrel6_varstim_no1stglu_recVGCC.py $gNa $gK 3e-05 ${EL} $decay $minCa $par None       2 $T $PasActLen 1 0.3 5e-06 1.0 100.0 1.0 1.0 1.0 0.001 0.001 1 0;done
  for T in 150.0 200.0 300.0 500.0 700.0 900.0 1300.0 1600.0; do echo "python3 presynGABAB_actpasaxon_rxdrel6_varstim_no1stglu_recVGCC.py $gNa $gK 3e-05 ${EL} $decay $minCa $par GABABRx0.0 2 $T $PasActLen 1 0.3 5e-06 1.0 100.0 1.0 1.0 1.0 0.001 0.001 1 0";python3 presynGABAB_actpasaxon_rxdrel6_varstim_no1stglu_recVGCC.py $gNa $gK 3e-05 ${EL} $decay $minCa $par GABABRx0.0 2 $T $PasActLen 1 0.3 5e-06 1.0 100.0 1.0 1.0 1.0 0.001 0.001 1 0;done
  for T in 350.0 550.0 750.0 1000.0 2000.0 3000.0 4000.0; do echo "python3 presynGABAB_actpasaxon_rxdrel6_varstim_recVGCC.py $gNa $gK 3e-05 ${EL} $decay $minCa $par None       $T $PasActLen 2 0.3 5e-06 1.0 100.0 1.0 1.0 1.0 0.001 0.001 1 0";python3 presynGABAB_actpasaxon_rxdrel6_varstim_recVGCC.py $gNa $gK 3e-05 ${EL} $decay $minCa $par None       $T $PasActLen 2 0.3 5e-06 1.0 100.0 1.0 1.0 1.0 0.001 0.001 1 0;done
  for T in 350.0 550.0 750.0 1000.0 2000.0 3000.0 4000.0; do echo "python3 presynGABAB_actpasaxon_rxdrel6_varstim_recVGCC.py $gNa $gK 3e-05 ${EL} $decay $minCa $par GABABRx0.0 $T $PasActLen 2 0.3 5e-06 1.0 100.0 1.0 1.0 1.0 0.001 0.001 1 0";python3 presynGABAB_actpasaxon_rxdrel6_varstim_recVGCC.py $gNa $gK 3e-05 ${EL} $decay $minCa $par GABABRx0.0 $T $PasActLen 2 0.3 5e-06 1.0 100.0 1.0 1.0 1.0 0.001 0.001 1 0;done

  #Control experiments
  for T in 150.0 200.0 300.0 500.0 700.0 900.0 1300.0 1600.0; do echo "python3 presynGABAB_actpasaxon_rxdrel6_varstim_recVGCC.py $gNa $gK 3e-05 ${EL} $decay $minCa $par None       $T $PasActLen 1 0.3 5e-06 1.0 100.0 1.0 1.0 1.0 0.001 0.001 1 0";python3 presynGABAB_actpasaxon_rxdrel6_varstim_recVGCC.py $gNa $gK 3e-05 ${EL} $decay $minCa $par None       $T $PasActLen 1 0.3 5e-06 1.0 100.0 1.0 1.0 1.0 0.001 0.001 1 0;done
  for T in 150.0 200.0 300.0 500.0 700.0 900.0 1300.0 1600.0; do echo "python3 presynGABAB_actpasaxon_rxdrel6_varstim_recVGCC.py $gNa $gK 3e-05 ${EL} $decay $minCa $par GABABRx0.0 $T $PasActLen 1 0.3 5e-06 1.0 100.0 1.0 1.0 1.0 0.001 0.001 1 0";python3 presynGABAB_actpasaxon_rxdrel6_varstim_recVGCC.py $gNa $gK 3e-05 ${EL} $decay $minCa $par GABABRx0.0 $T $PasActLen 1 0.3 5e-06 1.0 100.0 1.0 1.0 1.0 0.001 0.001 1 0;done

done
