nrnivmodl mechanisms

python3 drawmorph_distfromapicalbranch.py #Save morphology data for the panel A

GIRKconds=(0.0 0.033)
STD=45.0
iSTD=1
BLOCKED=gSKv3_1bar_SKv3_1
BLOCKEDCOEFF=2.5
par=p0

tstop=4000
T=3000
somaticIscale=1.0
conc=50.0

surfDensityGABA=8.3e-05
surfDensityGIRK=0.00022

Is=(0.0 0.25 0.5 0.75 1.0 1.25)

# Make simulations where Kv3.1 conductance is varied - no GIRK activation
for iGIRK in 0
do
    
    for BLOCKEDCOEFF in 1.0 2.0 2.5 3.0 4.0 5.0
    do
        for iI2 in 0 1 2 3 4 5
        do
            if [ -f fIbaclofen_constsurfGABAGIRK${surfDensityGABA}_${surfDensityGIRK}_${par}_${BLOCKED}x${BLOCKEDCOEFF}_${GIRKconds[iGIRK]}_tstop${tstop}_T${T}_st2ind${iI2}_somIsc${somaticIscale}_amp${Is[iI2]}_max${conc}_std${STD}.sav ]
            then
                echo "fIbaclofen_constsurfGABAGIRK${surfDensityGABA}_${surfDensityGIRK}_${par}_${BLOCKED}x${BLOCKEDCOEFF}_${GIRKconds[iGIRK]}_tstop${tstop}_T${T}_st2ind${iI2}_somIsc${somaticIscale}_amp${Is[iI2]}_max${conc}_std${STD}.sav exists"
            else
                echo "ls -l fIbaclofen_constsurfGABAGIRK${surfDensityGABA}_${surfDensityGIRK}_${par}_${BLOCKED}x${BLOCKEDCOEFF}_${GIRKconds[iGIRK]}_tstop${tstop}_T${T}_st2ind${iI2}_somIsc${somaticIscale}_amp${Is[iI2]}_max${conc}_std${STD}.sav"
                ls -l fIbaclofen_constsurfGABAGIRK${surfDensityGABA}_${surfDensityGIRK}_${par}_${BLOCKED}x${BLOCKEDCOEFF}_${GIRKconds[iGIRK]}_tstop${tstop}_T${T}_st2ind${iI2}_somIsc${somaticIscale}_amp${Is[iI2]}_max${conc}_std${STD}.sav
                echo "python3 calcFIplanes_withbaclofen_blocked_givenst2_givenT_scalesomaticI_varconc_constsurfGABAGIRK.py ${GIRKconds[iGIRK]} $tstop $T $conc ${STD} $iI2 ${BLOCKED}x${BLOCKEDCOEFF} $par $somaticIscale $surfDensityGABA $surfDensityGIRK 0"
                python3 calcFIplanes_withbaclofen_blocked_givenst2_givenT_scalesomaticI_varconc_constsurfGABAGIRK.py ${GIRKconds[iGIRK]} $tstop $T $conc ${STD} $iI2 ${BLOCKED}x${BLOCKEDCOEFF} $par $somaticIscale $surfDensityGABA $surfDensityGIRK 0
            fi
        done
    done
done

BLOCKEDCOEFF=2.5

# Make simulations where Kv3.1 conductance is fixed, with and without GIRK activation
for iGIRK in 0 1
do
    for par in p0 p1 p2 p3 p4 p5 p6 p7 p8 p9 p10 p11 p12 p13 p14
    do
        for iI2 in 0 1 2 3 4 5
        do
            if [ -f fIbaclofen_constsurfGABAGIRK${surfDensityGABA}_${surfDensityGIRK}_${par}_${BLOCKED}x${BLOCKEDCOEFF}_${GIRKconds[iGIRK]}_tstop${tstop}_T${T}_st2ind${iI2}_somIsc${somaticIscale}_amp${Is[iI2]}_max${conc}_std${STD}.sav ]
            then
                echo "fIbaclofen_constsurfGABAGIRK${surfDensityGABA}_${surfDensityGIRK}_${par}_${BLOCKED}x${BLOCKEDCOEFF}_${GIRKconds[iGIRK]}_tstop${tstop}_T${T}_st2ind${iI2}_somIsc${somaticIscale}_amp${Is[iI2]}_max${conc}_std${STD}.sav exists"
            else
                echo "ls -l fIbaclofen_constsurfGABAGIRK${surfDensityGABA}_${surfDensityGIRK}_${par}_${BLOCKED}x${BLOCKEDCOEFF}_${GIRKconds[iGIRK]}_tstop${tstop}_T${T}_st2ind${iI2}_somIsc${somaticIscale}_amp${Is[iI2]}_max${conc}_std${STD}.sav"
                ls -l fIbaclofen_constsurfGABAGIRK${surfDensityGABA}_${surfDensityGIRK}_${par}_${BLOCKED}x${BLOCKEDCOEFF}_${GIRKconds[iGIRK]}_tstop${tstop}_T${T}_st2ind${iI2}_somIsc${somaticIscale}_amp${Is[iI2]}_max${conc}_std${STD}.sav
                echo "python3 calcFIplanes_withbaclofen_blocked_givenst2_givenT_scalesomaticI_varconc_constsurfGABAGIRK.py ${GIRKconds[iGIRK]} $tstop $T $conc ${STD} $iI2 ${BLOCKED}x${BLOCKEDCOEFF} $par $somaticIscale $surfDensityGABA $surfDensityGIRK 0"
                python3 calcFIplanes_withbaclofen_blocked_givenst2_givenT_scalesomaticI_varconc_constsurfGABAGIRK.py ${GIRKconds[iGIRK]} $tstop $T $conc ${STD} $iI2 ${BLOCKED}x${BLOCKEDCOEFF} $par $somaticIscale $surfDensityGABA $surfDensityGIRK 0
            fi
        done
    done
done

