PasActLen='100 20'
PasActLenComma='100,20'
decay=1.0
EL=-90.0
gNa=3.9
gK=0.077
minCa=50e-6
amp=0.3

#Panels A-B
for par in p0 p1 p2 p3 p4 p5 p6 p7 p8 p9 p10 p11 p12 p13 p14; do
  for T in 350.0 550.0 750.0 1000.0 2000.0 3000.0 4000.0; do echo "python3 presynGABAB_actpasaxon_rxdrel6_varstim.py $gNa $gK 3e-05 ${EL} $decay $minCa $par None       $T $PasActLen 2 ${amp} 5e-06 1.0 100.0 1.0 1.0 1.0 0.001 0.001 1 0";python3 presynGABAB_actpasaxon_rxdrel6_varstim.py $gNa $gK 3e-05 ${EL} $decay $minCa $par None       $T $PasActLen 2 ${amp} 5e-06 1.0 100.0 1.0 1.0 1.0 0.001 0.001 1 0;done
  for T in 350.0 550.0 750.0 1000.0 2000.0 3000.0 4000.0; do echo "python3 presynGABAB_actpasaxon_rxdrel6_varstim.py $gNa $gK 3e-05 ${EL} $decay $minCa $par GABABRx0.0 $T $PasActLen 2 ${amp} 5e-06 1.0 100.0 1.0 1.0 1.0 0.001 0.001 1 0";python3 presynGABAB_actpasaxon_rxdrel6_varstim.py $gNa $gK 3e-05 ${EL} $decay $minCa $par GABABRx0.0 $T $PasActLen 2 ${amp} 5e-06 1.0 100.0 1.0 1.0 1.0 0.001 0.001 1 0;done
  for T in 150.0 200.0 300.0 500.0 700.0 900.0 1300.0 1600.0; do echo "python3 presynGABAB_actpasaxon_rxdrel6_varstim_no1stglu.py $gNa $gK 3e-05 ${EL} $decay $minCa $par None       $T $PasActLen 1 ${amp} 5e-06 1.0 100.0 1.0 1.0 1.0 0.001 0.001 1 0";python3 presynGABAB_actpasaxon_rxdrel6_varstim_no1stglu.py $gNa $gK 3e-05 ${EL} $decay $minCa $par None       $T $PasActLen 1 ${amp} 5e-06 1.0 100.0 1.0 1.0 1.0 0.001 0.001 1 0;done
  for T in 150.0 200.0 300.0 500.0 700.0 900.0 1300.0 1600.0; do echo "python3 presynGABAB_actpasaxon_rxdrel6_varstim_no1stglu.py $gNa $gK 3e-05 ${EL} $decay $minCa $par GABABRx0.0 $T $PasActLen 1 ${amp} 5e-06 1.0 100.0 1.0 1.0 1.0 0.001 0.001 1 0";python3 presynGABAB_actpasaxon_rxdrel6_varstim_no1stglu.py $gNa $gK 3e-05 ${EL} $decay $minCa $par GABABRx0.0 $T $PasActLen 1 ${amp} 5e-06 1.0 100.0 1.0 1.0 1.0 0.001 0.001 1 0;done
done

#Panels C-E

Nstims=3
Tlast=50.0
T=200.0 # T=150.0 (200.0 seems to be more accurate than 150.0)                                                                                                                                                   
for par in p0; do 
  echo "python3 presynGABAB_actpasaxon_rxdrel6_varstim_no1stglu_varlaststimT_recVGCC.py $gNa $gK 3e-05 ${EL} $decay $minCa $par None       $Nstims $T $Tlast $PasActLen 1 ${amp} 5e-06 1.0 100.0 1.0 1.0 1.0 0.001 0.001 1 0";python3 presynGABAB_actpasaxon_rxdrel6_varstim_no1stglu_varlaststimT_recVGCC.py $gNa $gK 3e-05 ${EL} $decay $minCa $par None       $Nstims $T $Tlast $PasActLen 1 ${amp} 5e-06 1.0 100.0 1.0 1.0 1.0 0.001 0.001 1 0
  echo "python3 presynGABAB_actpasaxon_rxdrel6_varstim_no1stglu_varlaststimT_recVGCC.py $gNa $gK 3e-05 ${EL} $decay $minCa $par GABABRx0.0 $Nstims $T $Tlast $PasActLen 1 ${amp} 5e-06 1.0 100.0 1.0 1.0 1.0 0.001 0.001 1 0";python3 presynGABAB_actpasaxon_rxdrel6_varstim_no1stglu_varlaststimT_recVGCC.py $gNa $gK 3e-05 ${EL} $decay $minCa $par GABABRx0.0 $Nstims $T $Tlast $PasActLen 1 ${amp} 5e-06 1.0 100.0 1.0 1.0 1.0 0.001 0.001 1 0
done
