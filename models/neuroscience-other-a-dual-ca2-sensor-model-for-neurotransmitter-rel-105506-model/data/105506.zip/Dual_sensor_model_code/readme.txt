This is the readme for the model associated with

Sun J, Pang ZP, Qin D, Fahim AT, Adachi R, Sudhof TC. 
A dual-Ca2+-sensor model for neurotransmitter release 
in a central synapse. Nature. 2007 Nov 29;450(7170):676-82.

The author's igor-pro function that defines the dual 
Ca2+ sensor is supplied.
