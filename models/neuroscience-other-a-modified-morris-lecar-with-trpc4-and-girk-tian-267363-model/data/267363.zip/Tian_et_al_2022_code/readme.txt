Code for Tian et al. 2022


gridsearch.m - Runs a gridsearch for the specified number of datapoints for gTRPC4 and gGIRK
mML_TRPC_GIRK.m - the neuron model called in gridsearch.m. Takes gmax values of gTRPC4 and gGIRK as input parameters
quantification_pause_tau - reproduces Fig5B-F in Tian et al. 2022