This is the readme.txt file for the models associated with the 
papers shown below:

1. A paper submitted in 2018

2. Hight AE, Kalluri R. A biophysical model examining the role of low-voltage-activated 
potassium currents in shaping the responses of vestibular ganglion neurons. 
J Neurophysiol. 2016 Aug 01; 116(2):503-21.

To run the simulation type Single_Compartment_Annotated at the Matlab command line.

To control the simulation parameters, open and edit the Single_Compartment_Annotated file.

Analysis scripts for Ventura & Kalluri (2018, submitted) can be found in the Analysis_Ventura & Kalluri subfolder.