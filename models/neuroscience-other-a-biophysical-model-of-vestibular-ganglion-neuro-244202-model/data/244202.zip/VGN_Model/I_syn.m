function I=I_syn(V)

global gb_syn Esyn

I=(V-Esyn)*gb_syn;

end