function I=I_l(V)

global gl El

I=(V-El)*gl;

end