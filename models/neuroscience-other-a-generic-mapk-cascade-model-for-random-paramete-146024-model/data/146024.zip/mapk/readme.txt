This is the readme for the model associated with the publication:

Mai Z, Liu H (2013) Random Parameter Sampling of a Generic Three-Tier
MAPK Cascade Model Reveals Major Factors Affecting Its Versatile
Dynamics. PLoS ONE 8(1): e54441. doi:10.1371/journal.pone.0054441

The models.m file is a matlab program.
